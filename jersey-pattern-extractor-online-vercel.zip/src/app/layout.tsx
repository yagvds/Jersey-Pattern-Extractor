import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Jersey Pattern Extractor — AI Studio",
  description: "AI-assisted jersey panel detection and flat pattern extraction."
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
