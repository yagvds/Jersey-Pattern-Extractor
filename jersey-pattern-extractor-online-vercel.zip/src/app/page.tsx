import PhaseTwoExtractor from "@/components/PhaseTwoExtractor";
export default function Home() { return <PhaseTwoExtractor />; }
