import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
const MAX_BYTES = 4 * 1024 * 1024;
const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp"]);

const panelTool = {
  name: "report_jersey_panels",
  description: "Return visible jersey fabric panel polygons in normalized image coordinates.",
  input_schema: {
    type: "object",
    additionalProperties: false,
    properties: {
      summary: { type: "string" },
      warnings: { type: "array", items: { type: "string" } },
      panels: {
        type: "array",
        items: {
          type: "object",
          additionalProperties: false,
          properties: {
            id: { type: "string", enum: ["front", "back", "left_sleeve", "right_sleeve", "other"] },
            label: { type: "string" },
            confidence: { type: "number", minimum: 0, maximum: 1 },
            polygon: {
              type: "array", minItems: 3,
              items: {
                type: "object", additionalProperties: false,
                properties: {
                  x: { type: "number", minimum: 0, maximum: 1 },
                  y: { type: "number", minimum: 0, maximum: 1 }
                },
                required: ["x", "y"]
              }
            },
            notes: { type: "string" }
          },
          required: ["id", "label", "confidence", "polygon", "notes"]
        }
      }
    },
    required: ["summary", "warnings", "panels"]
  }
};

export async function POST(request: NextRequest) {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  const model = process.env.ANTHROPIC_MODEL;
  if (!apiKey || !model) {
    return NextResponse.json(
      { error: "Server belum dikonfigurasi. Isi ANTHROPIC_API_KEY dan ANTHROPIC_MODEL di .env.local." },
      { status: 503 }
    );
  }

  const form = await request.formData();
  const file = form.get("image");
  if (!(file instanceof File)) return NextResponse.json({ error: "File image wajib dikirim." }, { status: 400 });
  if (!ALLOWED.has(file.type)) return NextResponse.json({ error: "Format harus PNG, JPG, atau WEBP." }, { status: 415 });
  if (file.size > MAX_BYTES) return NextResponse.json({ error: "Ukuran maksimum 4 MB pada deployment serverless ini." }, { status: 413 });

  const bytes = Buffer.from(await file.arrayBuffer());
  const base64 = bytes.toString("base64");
  const mediaType = file.type as "image/jpeg" | "image/png" | "image/webp";
  const baseUrl = (process.env.ANTHROPIC_BASE_URL || "https://api.anthropic.com").replace(/\/$/, "");
  const endpoint = `${baseUrl}/v1/messages`;

  const prompt = `Analyze this jersey mockup image. Identify only visible fabric regions that belong to the jersey: front body, back body, left sleeve, right sleeve, or other clearly separate fabric panel. Return polygons around the OUTER visible boundary of each identifiable fabric region, not logos or individual graphic shapes. Coordinates must be normalized from 0 to 1 relative to the full image: x=0 left, y=0 top. Use enough vertices to follow curved garment outlines (roughly 8-30 points per panel). Do not invent hidden fabric or unseen areas. Exclude skin, mannequin, background, shadows outside the garment, and accessories. If a panel is occluded or impossible to isolate, omit it and explain in warnings. Confidence should reflect boundary certainty.`;

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": process.env.ANTHROPIC_VERSION || "2023-06-01"
      },
      body: JSON.stringify({
        model,
        max_tokens: 1800,
        tools: [panelTool],
        tool_choice: { type: "tool", name: "report_jersey_panels" },
        messages: [{
          role: "user",
          content: [
            { type: "image", source: { type: "base64", media_type: mediaType, data: base64 } },
            { type: "text", text: prompt }
          ]
        }]
      })
    });

    const payload = await response.json();
    if (!response.ok) {
      const message = payload?.error?.message || `Gateway returned HTTP ${response.status}`;
      return NextResponse.json({ error: message }, { status: response.status });
    }
    const toolUse = payload?.content?.find((item: { type?: string; name?: string }) =>
      item.type === "tool_use" && item.name === "report_jersey_panels"
    );
    if (!toolUse?.input) return NextResponse.json({ error: "Model tidak mengembalikan data panel terstruktur." }, { status: 502 });
    return NextResponse.json(toolUse.input);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Gagal menghubungi AI gateway." },
      { status: 502 }
    );
  }
}
