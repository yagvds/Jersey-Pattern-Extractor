"use client";

import ImageTracer from "imagetracerjs";
import { ChangeEvent, useEffect, useMemo, useRef, useState } from "react";

type Point = { x: number; y: number };
type Panel = { id: string; label: string; confidence: number; polygon: Point[]; notes: string };
type Analysis = { summary: string; warnings: string[]; panels: Panel[] };

const W = 600, H = 900;

export default function PhaseTwoExtractor() {
  const [file, setFile] = useState<File | null>(null);
  const [source, setSource] = useState("");
  const [analysis, setAnalysis] = useState<Analysis | null>(null);
  const [selected, setSelected] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [svg, setSvg] = useState("");
  const [colors, setColors] = useState(16);
  const [cleanup, setCleanup] = useState(5);
  const imgRef = useRef<HTMLImageElement>(null);

  useEffect(() => () => { if (source) URL.revokeObjectURL(source); }, [source]);

  function upload(e: ChangeEvent<HTMLInputElement>) {
    const next = e.target.files?.[0];
    if (!next) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(next.type)) return setError("Format file harus PNG, JPG, atau WEBP.");
    if (next.size > 4 * 1024 * 1024) return setError("Ukuran maksimum 4 MB untuk versi hosting serverless.");
    setFile(next); setSource(URL.createObjectURL(next)); setAnalysis(null); setSvg(""); setError("");
  }

  async function analyze() {
    if (!file) return;
    setBusy(true); setError(""); setAnalysis(null); setSvg("");
    try {
      const body = new FormData(); body.append("image", file);
      const response = await fetch("/api/analyze", { method: "POST", body });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Analisis gagal.");
      if (!Array.isArray(data.panels) || data.panels.length === 0) throw new Error("AI belum menemukan panel yang dapat diisolasi. Coba mockup dengan sudut lebih jelas.");
      setAnalysis(data); setSelected(0);
    } catch (e) { setError(e instanceof Error ? e.message : "Analisis gagal."); }
    finally { setBusy(false); }
  }

  const activePanel = analysis?.panels[selected];
  const overlay = useMemo(() => {
    if (!analysis || !source) return "";
    return analysis.panels.map((p, i) => {
      const points = p.polygon.map(pt => `${pt.x * 1000},${pt.y * 1000}`).join(" ");
      return `<polygon points="${points}" fill="${i === selected ? "rgba(211,241,91,.28)" : "rgba(20,30,20,.08)"}" stroke="${i === selected ? "#c2e64c" : "#ffffff"}" stroke-width="4" />`;
    }).join("");
  }, [analysis, selected, source]);

  function extract() {
    const image = imgRef.current;
    if (!image || !activePanel) return;
    const xs = activePanel.polygon.map(p => p.x * image.naturalWidth);
    const ys = activePanel.polygon.map(p => p.y * image.naturalHeight);
    const minX = Math.max(0, Math.min(...xs)), maxX = Math.min(image.naturalWidth, Math.max(...xs));
    const minY = Math.max(0, Math.min(...ys)), maxY = Math.min(image.naturalHeight, Math.max(...ys));
    if (maxX - minX < 2 || maxY - minY < 2) return setError("Area panel terlalu kecil untuk diekstrak.");

    const work = document.createElement("canvas"); work.width = W; work.height = H;
    const ctx = work.getContext("2d", { willReadFrequently: true });
    if (!ctx) return setError("Canvas tidak tersedia.");
    ctx.fillStyle = "#ffffff"; ctx.fillRect(0, 0, W, H);
    const sx = W / (maxX - minX), sy = H / (maxY - minY);
    ctx.save(); ctx.beginPath();
    activePanel.polygon.forEach((p, i) => {
      const x = (p.x * image.naturalWidth - minX) * sx;
      const y = (p.y * image.naturalHeight - minY) * sy;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.closePath(); ctx.clip();
    ctx.drawImage(image, minX, minY, maxX - minX, maxY - minY, 0, 0, W, H);
    ctx.restore();

    const data = ctx.getImageData(0, 0, W, H);
    const traced = ImageTracer.imagedataToSVG(data, {
      numberofcolors: colors, pathomit: cleanup, ltres: 1, qtres: 1,
      rightangleenhance: true, colorsampling: 2, layering: 0,
      scale: 1, viewbox: true, desc: false
    });
    // Set physical SVG dimensions to 600 × 900 mm (= 60 × 90 cm).
    const result = traced.replace(/<svg\\b([^>]*)>/, (_match, attrs) => {
      const cleaned = attrs.replace(/\\s(width|height)="[^"]*"/g, "");
      return `<svg${cleaned} width="600mm" height="900mm" viewBox="0 0 600 900">`;
    });
    setSvg(result); setError("");
  }

  function downloadSvg() {
    if (!svg) return;
    const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml;charset=utf-8" }));
    const a = document.createElement("a"); a.href = url; a.download = `jersey-${activePanel?.id || "panel"}-60x90.svg`; a.click(); URL.revokeObjectURL(url);
  }

  function downloadPng() {
    if (!svg) return;
    const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml;charset=utf-8" }));
    const image = new Image();
    image.onload = () => {
      const canvas = document.createElement("canvas"); canvas.width = 2400; canvas.height = 3600;
      const ctx = canvas.getContext("2d"); if (!ctx) return;
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
      canvas.toBlob(blob => {
        if (!blob) return;
        const pngUrl = URL.createObjectURL(blob); const a = document.createElement("a");
        a.href = pngUrl; a.download = `jersey-${activePanel?.id || "panel"}-60x90.png`; a.click();
        URL.revokeObjectURL(pngUrl); URL.revokeObjectURL(url);
      }, "image/png");
    };
    image.src = url;
  }

  return <main className="shell">
    <header className="nav"><a className="brand" href="#">THREAD / LAB <span>AI STUDIO</span></a><span className="live"><i/> PHASE 02 / PANEL DETECTION</span></header>
    <section className="hero"><p className="kicker">DIGITAL TEXTILE TOOLKIT / 002</p><h1>From jersey<br/><em>to flat pattern.</em></h1><p>Detect garment panels from a jersey mockup, isolate the visible fabric, and prepare a 60 × 90 cm flat artwork canvas.</p></section>

    <section className="grid">
      <aside className="panel settings">
        <div className="section-title"><span>01</span><h2>Source mockup</h2></div>
        <label className="drop"><input type="file" accept="image/png,image/jpeg,image/webp" onChange={upload}/><b>＋</b><strong>Upload jersey mockup</strong><small>PNG / JPG / WEBP · MAX 4 MB</small></label>
        {source && <div className="fileline"><span>{file?.name}</span><button onClick={()=>{setFile(null);setSource("");setAnalysis(null);setSvg("");}}>REMOVE</button></div>}
        <button className="action" disabled={!file || busy} onClick={analyze}>{busy ? "ANALYZING GARMENT..." : "✳  DETECT JERSEY PANELS"}</button>
        <p className="hint">AI identifies visible front, back, and sleeve regions. Review its polygon boundaries before extraction.</p>
        {analysis && <>
          <div className="rule"/>
          <div className="section-title"><span>02</span><h2>Detected panels</h2></div>
          <p className="summary">{analysis.summary}</p>
          <div className="panel-list">{analysis.panels.map((p,i)=><button key={`${p.id}-${i}`} className={selected===i?"panel-choice active":"panel-choice"} onClick={()=>{setSelected(i);setSvg("");}}><span><b>{p.label}</b><small>{Math.round(p.confidence*100)}% confidence</small></span><i>{selected===i?"●":"○"}</i></button>)}</div>
          {activePanel && <p className="hint">AI note: {activePanel.notes}</p>}
          {analysis.warnings?.length>0 && <div className="warning">{analysis.warnings.map((w,i)=><p key={i}>! {w}</p>)}</div>}
          <div className="rule"/>
          <div className="section-title"><span>03</span><h2>Vector settings</h2></div>
          <label className="range">Color count <b>{colors}</b><input type="range" min="2" max="32" value={colors} onChange={e=>setColors(Number(e.target.value))}/></label>
          <label className="range">Path cleanup <b>{cleanup}</b><input type="range" min="0" max="30" value={cleanup} onChange={e=>setCleanup(Number(e.target.value))}/></label>
          <button className="action" onClick={extract}>EXTRACT SELECTED PANEL ↗</button>
        </>}
        {error && <p className="error">{error}</p>}
        <p className="privacy">Image is sent to your configured Anthropic-compatible gateway for visual analysis. The API key stays server-side.</p>
      </aside>

      <section className="panel workspace">
        <div className="workspace-head"><div className="section-title"><span>VIEW</span><h2>Garment analysis</h2></div><span className="dimension">60 × 90 CM / 2:3</span></div>
        <div className="viewarea">
          {source ? <div className="image-wrap"><img ref={imgRef} src={source} alt="Uploaded jersey mockup"/>{analysis && <svg className="overlay" viewBox="0 0 1000 1000" preserveAspectRatio="none" dangerouslySetInnerHTML={{__html:overlay}}/>}</div> : <div className="placeholder"><b>✳</b><strong>Upload a jersey mockup to begin</strong><span>Detected panel boundaries will appear over the image.</span></div>}
        </div>
        <div className="workspace-head result-head"><div className="section-title"><span>OUTPUT</span><h2>Flat pattern canvas</h2></div><span className="dimension">600 × 900 VIEWBOX</span></div>
        <div className="result-area"><div className="artboard">{svg ? <img src={`data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`} alt="Extracted vector panel"/> : <div><b>60 × 90</b><span>Extract a detected panel to preview output</span></div>}</div></div>
        <div className="exports"><span>{svg ? "VECTOR READY · 60 × 90 CM" : "WAITING FOR PANEL EXTRACTION"}</span><div><button disabled={!svg} onClick={downloadSvg}>↓ SVG</button><button disabled={!svg} onClick={downloadPng}>↓ PNG</button></div></div>
      </section>
    </section>
    <footer><span>THREAD / LAB © 2026</span><span>AI-ASSISTED TEXTILE WORKFLOW</span></footer>
  </main>;
}
